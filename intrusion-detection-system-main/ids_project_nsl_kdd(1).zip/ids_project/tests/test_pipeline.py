"""
Tests unitaires pour le projet IDS NSL-KDD
Exécution : python -m pytest tests/ -v
"""
import sys, os, json
import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ATTACK_CATEGORIES, COLUMNS, MODELS_DIR


class TestConfig:
    def test_columns_count(self):
        assert len(COLUMNS) == 43  # 41 features + label + difficulty

    def test_attack_categories_non_empty(self):
        assert len(ATTACK_CATEGORIES) > 0

    def test_normal_category(self):
        assert ATTACK_CATEGORIES.get('normal') == 'Normal'

    def test_dos_attacks(self):
        dos = [k for k, v in ATTACK_CATEGORIES.items() if v == 'DoS']
        assert 'neptune' in dos and 'smurf' in dos

    def test_u2r_attacks(self):
        u2r = [k for k, v in ATTACK_CATEGORIES.items() if v == 'U2R']
        assert 'buffer_overflow' in u2r


class TestPreprocessing:
    def test_import(self):
        from src.preprocessing.data_loader import (
            load_dataset, map_attack_categories,
            encode_categorical, split_features_labels, normalize
        )
        assert True

    def test_map_attack_categories(self):
        import pandas as pd
        from src.preprocessing.data_loader import map_attack_categories
        df = pd.DataFrame({'label': ['normal', 'neptune', 'nmap', 'buffer_overflow', 'warezclient']})
        result = map_attack_categories(df)
        assert result['category'].tolist() == ['Normal', 'DoS', 'Probe', 'U2R', 'R2L']

    def test_normalize_shape(self):
        from src.preprocessing.data_loader import normalize
        X_tr = np.random.rand(100, 10)
        X_te = np.random.rand(20, 10)
        Xtr_s, Xte_s, scaler = normalize(X_tr, X_te)
        assert Xtr_s.shape == (100, 10)
        assert Xte_s.shape == (20, 10)
        assert abs(Xtr_s.mean()) < 0.1  # Proche de 0

    def test_normalize_no_test_leakage(self):
        """Le scaler ne doit pas être ajusté sur le test."""
        from src.preprocessing.data_loader import normalize
        X_tr = np.ones((50, 5)) * 10
        X_te = np.ones((10, 5)) * 100
        Xtr_s, Xte_s, _ = normalize(X_tr, X_te)
        assert abs(Xtr_s.mean()) < 0.01
        assert Xte_s.mean() > 1  # Test non normalisé au sens train


class TestModels:
    def test_import_trainer(self):
        from src.models.trainer import (
            train_random_forest, train_knn, evaluate_model,
            get_feature_importances, save_artifacts, load_artifacts
        )
        assert True

    def test_rf_trains(self):
        from src.models.trainer import train_random_forest
        import pandas as pd
        X = np.random.rand(200, 10)
        y = pd.Series(['normal', 'neptune'] * 100)
        clf = train_random_forest(X, y, params={'n_estimators':5, 'random_state':42, 'n_jobs':1})
        preds = clf.predict(X[:5])
        assert len(preds) == 5

    def test_knn_trains(self):
        from src.models.trainer import train_knn
        import pandas as pd
        X = np.random.rand(100, 10)
        y = pd.Series(['normal', 'neptune'] * 50)
        clf = train_knn(X, y, params={'n_neighbors':3, 'n_jobs':1}, subset_size=100)
        preds = clf.predict(X[:5])
        assert len(preds) == 5

    def test_feature_importances(self):
        from src.models.trainer import train_random_forest, get_feature_importances
        import pandas as pd
        X = np.random.rand(100, 5)
        y = pd.Series(['a', 'b'] * 50)
        clf = train_random_forest(X, y, params={'n_estimators':5, 'random_state':0, 'n_jobs':1})
        imps = get_feature_importances(clf, ['f1','f2','f3','f4','f5'])
        assert len(imps) == 5
        assert abs(sum(v for _, v in imps) - 1.0) < 0.001


class TestMetrics:
    """Test les métriques sauvegardées si disponibles."""

    def test_metrics_structure(self):
        path = os.path.join(MODELS_DIR, 'metrics.json')
        if not os.path.exists(path):
            pytest.skip("metrics.json non trouvé — entraînez d'abord le modèle")
        with open(path) as f:
            m = json.load(f)
        assert 'rf' in m and 'knn' in m
        assert 'accuracy' in m['rf'] and 'accuracy' in m['knn']
        assert m['rf']['accuracy'] > 0.5
        assert m['knn']['accuracy'] > 0.5

    def test_feature_importances_sum(self):
        path = os.path.join(MODELS_DIR, 'metrics.json')
        if not os.path.exists(path):
            pytest.skip("metrics.json non trouvé")
        with open(path) as f:
            m = json.load(f)
        feats = m.get('top_features', [])
        if feats:
            total = sum(v for _, v in feats)
            assert total <= 1.01  # Peut être partiel (top 15)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
