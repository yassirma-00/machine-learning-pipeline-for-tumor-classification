"""
Script principal d'entraînement - Point d'entrée
Usage : python train.py

Ce script :
  1. Charge et prétraite les données NSL-KDD
  2. Entraîne Random Forest + KNN
  3. Évalue les deux modèles
  4. Sauvegarde tous les artefacts dans /models/
"""
import os, sys, json
import numpy as np

# Ajouter le répertoire racine au path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import TRAIN_FILE, TEST_FILE, MODELS_DIR, ATTACK_CATEGORIES
from src.preprocessing.data_loader import full_pipeline
from src.models.trainer import (
    train_random_forest, train_knn,
    evaluate_model, get_feature_importances,
    save_artifacts
)


def main():
    print("\n" + "█"*55)
    print("  SYSTÈME IDS NSL-KDD — PIPELINE D'ENTRAÎNEMENT")
    print("█"*55)

    # ── ÉTAPE 1 : Prétraitement ──────────────────────────────
    data = full_pipeline(TRAIN_FILE, TEST_FILE)
    X_train = data['X_train']
    X_test = data['X_test']
    y_train = data['y_train']
    y_test = data['y_test']
    y_train_cat = data['y_train_cat']
    y_test_cat = data['y_test_cat']
    feature_names = data['feature_names']
    scaler = data['scaler']
    encoders = data['encoders']

    # ── ÉTAPE 2 : Entraînement ───────────────────────────────
    print("\n" + "="*55)
    print("  ÉTAPE 2 : ENTRAÎNEMENT DES MODÈLES")
    print("="*55)
    rf = train_random_forest(X_train, y_train)
    knn = train_knn(X_train, y_train)

    # ── ÉTAPE 3 : Évaluation ─────────────────────────────────
    print("\n" + "="*55)
    print("  ÉTAPE 3 : ÉVALUATION")
    print("="*55)
    rf_metrics = evaluate_model(rf, X_test, y_test, y_test_cat, "Random Forest")
    knn_metrics = evaluate_model(knn, X_test, y_test, y_test_cat, "KNN")

    # Importances de features
    top_features = get_feature_importances(rf, feature_names)

    # Distributions
    class_dist = data['train_df']['label'].value_counts().to_dict()
    cat_dist = data['train_df']['category'].value_counts().to_dict()

    all_metrics = {
        'rf': rf_metrics,
        'knn': knn_metrics,
        'top_features': top_features[:15],
        'class_distribution': class_dist,
        'category_distribution': cat_dist,
        'attack_categories': ATTACK_CATEGORIES,
        'training_samples': int(X_train.shape[0]),
        'test_samples': int(X_test.shape[0]),
        'n_features': int(X_train.shape[1]),
    }

    # ── ÉTAPE 4 : Sauvegarde ─────────────────────────────────
    print("\n" + "="*55)
    print("  ÉTAPE 4 : SAUVEGARDE")
    print("="*55)
    save_artifacts(rf, knn, scaler, encoders,
                   all_metrics, feature_names, MODELS_DIR)

    # ── Résumé final ──────────────────────────────────────────
    print("\n" + "█"*55)
    print("  RÉSUMÉ FINAL")
    print("█"*55)
    print(f"  Random Forest  : accuracy={rf_metrics['accuracy']:.4f}  "
          f"f1_macro={rf_metrics['f1_macro']:.4f}")
    print(f"  KNN (k=5)      : accuracy={knn_metrics['accuracy']:.4f}  "
          f"f1_macro={knn_metrics['f1_macro']:.4f}")
    print(f"\n  Artefacts sauvegardés dans : {MODELS_DIR}/")
    print("\n  Lancer l'interface : python src/api/app.py")
    print("█"*55 + "\n")


if __name__ == '__main__':
    main()
