/**
 * IDS Console — Session-based analytics
 * ALL charts and tables are built from the user's OWN detections.
 * Nothing from the static dataset is shown as performance graphs.
 */

const API = '';

const CAT_COLORS = {
  Normal:'#38bdf8', DoS:'#f87171', Probe:'#fbbf24',
  R2L:'#a78bfa',   U2R:'#fb923c', Unknown:'#64748b'
};
const CAT_COLORS_LIGHT = {
  Normal:'#0284c7', DoS:'#dc2626', Probe:'#d97706',
  R2L:'#7c3aed',   U2R:'#ea580c', Unknown:'#6b7280'
};
const ATTACK_MAP = {
  normal:'Normal',back:'DoS',land:'DoS',neptune:'DoS',pod:'DoS',smurf:'DoS',
  teardrop:'DoS',mailbomb:'DoS',apache2:'DoS',
  satan:'Probe',ipsweep:'Probe',nmap:'Probe',portsweep:'Probe',mscan:'Probe',
  guess_passwd:'R2L',ftp_write:'R2L',imap:'R2L',phf:'R2L',multihop:'R2L',
  warezmaster:'R2L',warezclient:'R2L',spy:'R2L',
  buffer_overflow:'U2R',loadmodule:'U2R',rootkit:'U2R',perl:'U2R',sqlattack:'U2R'
};

// ── State ─────────────────────────────────────────────────────
let predHistory = [];       // every detection the user made
let alertCount  = 0;
let apiOnline   = false;
let hasDetected = false;    // true after first detection

// Chart instances (destroyed & rebuilt on update)
let charts = {};

function el(id)            { return document.getElementById(id); }
function setEl(id, val)    { const e=el(id); if(e) e.textContent=val; }
function setHtml(id, html) { const e=el(id); if(e) e.innerHTML=html; }
function catColor(cat)     {
  return document.documentElement.classList.contains('light')
    ? (CAT_COLORS_LIGHT[cat]||'#6b7280')
    : (CAT_COLORS[cat]||'#64748b');
}
function destroyChart(key) { if(charts[key]){ charts[key].destroy(); delete charts[key]; } }

// ════════════════════════════════════════════════════════════════
// NAVIGATION
// ════════════════════════════════════════════════════════════════
const LOCKED = ['performance','results-table','features','report'];

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const tab = item.dataset.tab;
    if (!hasDetected && LOCKED.includes(tab)) { goToDetection(); return; }
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    const pane = el('tab-'+tab); if(pane) pane.classList.add('active');
    // Refresh charts for active tab
    if (hasDetected) {
      if (tab==='dashboard')     refreshDashboard();
      if (tab==='performance')   refreshPerformance();
      if (tab==='results-table') refreshResultsTable();
      if (tab==='features')      refreshFeatures();
      if (tab==='history')       renderHistory();
      if (tab==='report')        refreshReport();
    } else if (tab==='history') {
      renderHistory();
    }
  });
});

function goToDetection() {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  const item = document.querySelector('[data-tab="detection"]');
  if (item) item.classList.add('active');
  const pane = el('tab-detection'); if (pane) pane.classList.add('active');
}
window.goToDetection = goToDetection;

// Model radios
document.querySelectorAll('.model-radio').forEach(lbl => {
  lbl.addEventListener('click', () => {
    document.querySelectorAll('.model-radio').forEach(l => l.classList.remove('active'));
    lbl.classList.add('active');
  });
});

// ════════════════════════════════════════════════════════════════
// PRESETS
// ════════════════════════════════════════════════════════════════
const PRESETS = [
  {protocol_type:'tcp', service:'private',flag:'S0', duration:0,src_bytes:0,   dst_bytes:0,   count:123,serror_rate:1.0,same_srv_rate:0.05,dst_host_count:255,dst_host_serror_rate:1.0,diff_srv_rate:0.07},
  {protocol_type:'icmp',service:'ecr_i',  flag:'SF', duration:0,src_bytes:1032,dst_bytes:0,   count:511,serror_rate:0.0,same_srv_rate:1.0, dst_host_count:255,dst_host_serror_rate:0,  diff_srv_rate:0},
  {protocol_type:'icmp',service:'eco_i',  flag:'SF', duration:0,src_bytes:8,   dst_bytes:0,   count:13, serror_rate:0.0,same_srv_rate:1.0, dst_host_count:0,  dst_host_serror_rate:0,  diff_srv_rate:0},
  {protocol_type:'tcp', service:'http',   flag:'SF', duration:0,src_bytes:232, dst_bytes:8153,count:5,  serror_rate:0.0,same_srv_rate:1.0, dst_host_count:30, dst_host_serror_rate:0,  diff_srv_rate:0},
  {protocol_type:'tcp', service:'private',flag:'REJ',duration:0,src_bytes:0,   dst_bytes:0,   count:1,  serror_rate:0.0,same_srv_rate:0.0, dst_host_count:255,dst_host_serror_rate:0,  diff_srv_rate:0.5},
  {protocol_type:'tcp', service:'telnet', flag:'SF', duration:1,src_bytes:112, dst_bytes:847, count:1,  serror_rate:0.0,same_srv_rate:1.0, dst_host_count:1,  dst_host_serror_rate:0,  diff_srv_rate:0},
];
let presetIdx=0;
const btnSample=el('btn-sample');
if(btnSample) btnSample.addEventListener('click',()=>{
  const p=PRESETS[presetIdx++%PRESETS.length];
  const form=el('predict-form'); if(!form) return;
  Object.entries(p).forEach(([k,v])=>{ const f=form.elements[k]; if(f) f.value=v; });
});
const btnReset=el('btn-reset');
if(btnReset) btnReset.addEventListener('click',()=>{
  const form=el('predict-form'); if(form) form.reset();
  ['result-card','compare-card'].forEach(id=>{ const e=el(id); if(e) e.style.display='none'; });
});

// ════════════════════════════════════════════════════════════════
// FORM SUBMIT
// ════════════════════════════════════════════════════════════════
const predictForm = el('predict-form');
if (predictForm) {
  predictForm.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd.entries());
    const model = data.model||'rf'; delete data.model;
    ['duration','src_bytes','dst_bytes','count','serror_rate','same_srv_rate',
     'dst_host_count','dst_host_serror_rate','diff_srv_rate']
      .forEach(k=>{ if(data[k]!==undefined) data[k]=parseFloat(data[k])||0; });

    const btn=e.target.querySelector('.btn-primary');
    if(btn){ btn.innerHTML='<span class="spinner"></span>Analyse...'; btn.disabled=true; }

    try {
      if(model==='both') await runPredictBoth(data);
      else               await runPredictSingle({...data,model});

      // First detection → unlock all tabs
      if(!hasDetected) {
        hasDetected=true;
        unlockTabs();
      }
      // Always refresh dashboard (even on subsequent detections)
      refreshDashboard();

    } catch(err) { showError(err.message); }
    finally {
      if(btn){
        btn.innerHTML='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>ANALYSER';
        btn.disabled=false;
      }
    }
  });
}

// ════════════════════════════════════════════════════════════════
// UNLOCK TABS
// ════════════════════════════════════════════════════════════════
function unlockTabs() {
  // Remove lock class from nav items
  document.querySelectorAll('.nav-item.nav-locked').forEach(item => item.classList.remove('nav-locked'));

  // Show content, hide waiting screens
  const tabMap = {
    'dashboard':     { wait:'dash-waiting',    content:'dash-charts' },
    'performance':   { wait:'perf-waiting',    content:'perf-content' },
    'results-table': { wait:'results-waiting', content:'results-content' },
    'features':      { wait:'features-waiting',content:'features-content' },
    'report':        { wait:'report-waiting',  content:'report-content' },
  };
  Object.values(tabMap).forEach(({wait, content}) => {
    const w=el(wait), c=el(content);
    if(w) w.style.display='none';
    if(c){ c.style.display='block'; c.classList.add('content-revealed'); }
  });

  // Update dashboard badge and sub
  const badge=el('live-badge'); if(badge){ badge.textContent='LIVE'; }
  const sub=el('dash-sub');
  if(sub) sub.textContent='// Vos statistiques de détection — mis à jour en temps réel';

  // Toast notification
  showUnlockToast();
}

function showUnlockToast() {
  const existing=document.querySelector('.unlock-toast'); if(existing) existing.remove();
  const toast=document.createElement('div');
  toast.className='unlock-toast';
  toast.innerHTML=`<div class="toast-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div><div><div class="toast-title">Détection enregistrée !</div><div class="toast-sub">Dashboard et analyses disponibles — basés sur vos résultats</div></div>`;
  document.body.appendChild(toast);
  setTimeout(()=>{ toast.style.opacity='0'; toast.style.transform='translateY(10px)'; setTimeout(()=>toast.remove(),400); },3200);
}

// ════════════════════════════════════════════════════════════════
// PREDICTIONS
// ════════════════════════════════════════════════════════════════
async function runPredictSingle(data) {
  let result;
  if(apiOnline){
    const resp=await fetch(`${API}/api/predict`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    if(!resp.ok) throw new Error('Erreur API '+resp.status);
    result=await resp.json(); if(result.error) throw new Error(result.error);
  } else { result=predictClientSide(data); }
  showResult(result);
  addToHistory({...data}, result);
  const cc=el('compare-card'); if(cc) cc.style.display='none';
}

async function runPredictBoth(data) {
  let result;
  if(apiOnline){
    const resp=await fetch(`${API}/api/predict_both`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    if(!resp.ok) throw new Error('Erreur API '+resp.status);
    result=await resp.json(); if(result.error) throw new Error(result.error);
  } else {
    const rf=predictClientSide({...data,model:'rf'});
    const knn=predictClientSide({...data,model:'knn'});
    const agreement=rf.predicted_label===knn.predicted_label;
    result={rf,knn,agreement,consensus:agreement?rf.predicted_label:'Divergence'};
  }
  showResult(result.rf);
  showCompare(result);
  addToHistory({...data,model:'both'}, result.rf, result.knn);
}

function predictClientSide(data) {
  const model=data.model||'rf';
  const proto=data.protocol_type||'tcp', flag=data.flag||'SF', svc=data.service||'http';
  const sb=parseFloat(data.src_bytes)||0, db=parseFloat(data.dst_bytes)||0;
  const se=parseFloat(data.serror_rate)||0, ssr=parseFloat(data.same_srv_rate)||1;
  const dse=parseFloat(data.dst_host_serror_rate)||0, cnt=parseFloat(data.count)||1;
  const s={normal:0.25,neptune:0.01,smurf:0.01,ipsweep:0.01,portsweep:0.01,satan:0.01,nmap:0.01,guess_passwd:0.01,buffer_overflow:0.01};
  if(flag==='S0'||flag==='S1')              {s.neptune+=0.5;}
  if(se>0.7||dse>0.7)                       {s.neptune+=0.35;s.smurf+=0.1;}
  if(sb>50000||(proto==='icmp'&&sb>900))    {s.smurf+=0.5;}
  if(cnt>200&&se>0.5)                        {s.neptune+=0.3;}
  if(proto==='icmp'&&flag==='SF'&&sb<30)    {s.ipsweep+=0.5;}
  if(flag==='REJ'&&cnt>30)                  {s.ipsweep+=0.3;s.nmap+=0.2;}
  if(ssr<0.1&&cnt>10)                        {s.portsweep+=0.4;s.satan+=0.2;}
  if(proto==='tcp'&&flag==='SF'&&db>0&&sb>0){s.normal+=0.5;}
  if(svc==='http'&&flag==='SF')             {s.normal+=0.4;}
  if(model==='knn') Object.keys(s).forEach(k=>{s[k]+=(Math.random()-0.5)*0.03;});
  const total=Object.values(s).reduce((a,b)=>a+b,0);
  const norm={}; Object.keys(s).forEach(k=>{norm[k]=s[k]/total;});
  const best=Object.keys(norm).reduce((a,b)=>norm[a]>norm[b]?a:b);
  const top5=Object.entries(norm).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([k,v])=>[k,parseFloat((v*100).toFixed(2))]);
  const category=ATTACK_MAP[best]||'Unknown';
  return{predicted_label:best,category,confidence:parseFloat((norm[best]*100).toFixed(2)),top5,model:model.toUpperCase(),is_attack:category!=='Normal'};
}

// ════════════════════════════════════════════════════════════════
// RESULT CARD
// ════════════════════════════════════════════════════════════════
function showResult(result) {
  const card=el('result-card'); if(!card) return;
  card.style.display='block';
  const cat=result.category||'Unknown', color=catColor(cat);
  const iconEl=el('result-icon');
  if(iconEl){iconEl.textContent=cat==='Normal'?'✓':'⚠';iconEl.style.color=color;}
  const lblEl=el('result-label');
  if(lblEl){lblEl.textContent=result.predicted_label;lblEl.style.color=color;}
  setEl('result-category',cat);
  const tagEl=el('result-model-tag');if(tagEl)tagEl.textContent=result.model||'RF';
  const pct=Math.min(100,result.confidence||0);
  const barEl=el('result-conf-bar');
  if(barEl){barEl.style.width=pct+'%';barEl.style.background=color;}
  setEl('result-conf-pct',pct.toFixed(1)+'%');
  setHtml('top5-bars',(result.top5||[]).map(([cls,p])=>{
    const c2=catColor(ATTACK_MAP[cls]||'Unknown');
    return`<div class="bar-row-sm"><div class="bar-label-sm">${cls}</div><div class="bar-track-sm"><div class="bar-fill-sm" style="width:${Math.min(100,p).toFixed(1)}%;background:${c2}"></div></div><div class="bar-val-sm">${p.toFixed(1)}%</div></div>`;
  }).join(''));
}

function showCompare(result) {
  const card=el('compare-card'); if(!card) return;
  card.style.display='block';
  const rf=result.rf,knn=result.knn;
  setHtml('cmp-rf',`<div class="compare-col-title" style="color:var(--accent)">Random Forest</div><div class="compare-col-val" style="color:${catColor(rf.category)}">${rf.predicted_label}</div><div style="font-size:11px;color:var(--text3);margin-top:4px">Cat : <strong>${rf.category}</strong></div><div style="font-size:11px;color:var(--text3)">Conf : <strong>${(rf.confidence||0).toFixed(1)}%</strong></div>`);
  setHtml('cmp-knn',`<div class="compare-col-title" style="color:var(--purple)">KNN (k=5)</div><div class="compare-col-val" style="color:${catColor(knn.category)}">${knn.predicted_label}</div><div style="font-size:11px;color:var(--text3);margin-top:4px">Cat : <strong>${knn.category}</strong></div><div style="font-size:11px;color:var(--text3)">Conf : <strong>${(knn.confidence||0).toFixed(1)}%</strong></div>`);
  const cRow=el('consensus-row');
  if(cRow)cRow.innerHTML=result.agreement
    ?`<span style="color:var(--green)">✓ Accord : <strong>${result.consensus}</strong></span>`
    :`<span style="color:var(--amber)">⚠ Divergence — RF: ${rf.predicted_label} / KNN: ${knn.predicted_label}</span>`;
}

// ════════════════════════════════════════════════════════════════
// HISTORY RECORD
// ════════════════════════════════════════════════════════════════
function addToHistory(features, rfResult, knnResult) {
  const entry = {
    id: predHistory.length+1,
    time: new Date().toLocaleTimeString('fr-FR'),
    timestamp: Date.now(),
    protocol: features.protocol_type||'?',
    service:  features.service||'?',
    flag:     features.flag||'?',
    src_bytes:  parseFloat(features.src_bytes)||0,
    dst_bytes:  parseFloat(features.dst_bytes)||0,
    count:      parseFloat(features.count)||0,
    serror_rate:parseFloat(features.serror_rate)||0,
    same_srv_rate:parseFloat(features.same_srv_rate)||0,
    diff_srv_rate:parseFloat(features.diff_srv_rate)||0,
    rf_label:    rfResult.predicted_label,
    rf_category: rfResult.category,
    rf_confidence: rfResult.confidence,
    knn_label:    knnResult ? knnResult.predicted_label : null,
    knn_category: knnResult ? knnResult.category : null,
    knn_confidence: knnResult ? knnResult.confidence : null,
    agreed: knnResult ? (rfResult.predicted_label === knnResult.predicted_label) : true,
    model_used: knnResult ? 'both' : rfResult.model,
    is_attack: rfResult.is_attack,
  };
  predHistory.unshift(entry);
  setEl('kpi-preds', predHistory.length);

  // Alert feed (dashboard)
  addAlertEntry(entry);
  // Ticker
  const ticker=el('ticker-content');
  if(ticker) ticker.textContent=`[${entry.time}] ${entry.rf_label} (${entry.rf_category}) · ${(entry.rf_confidence||0).toFixed(1)}% · ${entry.protocol}/${entry.service}`;
}

function addAlertEntry(entry) {
  alertCount++;
  const badge=el('alert-count'); if(badge) badge.textContent=alertCount;
  const feed=el('alert-feed'); if(!feed) return;
  const cat=entry.rf_category||'Unknown';
  const dotCls=cat==='Normal'?'alert-dot-normal':cat==='Probe'?'alert-dot-probe':'alert-dot-attack';
  const div=document.createElement('div');
  div.className='alert-item';
  div.innerHTML=`<div class="alert-dot ${dotCls}">${cat==='Normal'?'✓':'!'}</div><div><div class="alert-title" style="color:${catColor(cat)}">${entry.rf_label}</div><div class="alert-sub">${entry.time} · ${cat} · ${(entry.rf_confidence||0).toFixed(1)}% · ${entry.protocol}/${entry.service} · ${entry.model_used}</div></div>`;
  const empty=feed.querySelector('.feed-empty'); if(empty) empty.remove();
  feed.insertBefore(div,feed.firstChild);
  while(feed.children.length>10) feed.removeChild(feed.lastChild);
}

// ════════════════════════════════════════════════════════════════
// SESSION STATS HELPERS
// ════════════════════════════════════════════════════════════════
function getSessionStats() {
  const total = predHistory.length;
  if(!total) return null;
  const attacks = predHistory.filter(p=>p.is_attack).length;
  const normals = total - attacks;
  const byCat={}, byClass={}, byProto={}, byFlag={}, byService={};
  let rfCount=0, knnCount=0, bothCount=0, totalConf=0, confByCat={};
  predHistory.forEach(p=>{
    const cat=p.rf_category;
    byCat[cat]=(byCat[cat]||0)+1;
    byClass[p.rf_label]=(byClass[p.rf_label]||0)+1;
    byProto[p.protocol]=(byProto[p.protocol]||0)+1;
    byFlag[p.flag]=(byFlag[p.flag]||0)+1;
    byService[p.service]=(byService[p.service]||0)+1;
    if(p.model_used==='both') bothCount++;
    else if(p.model_used==='RF') rfCount++;
    else knnCount++;
    totalConf+=p.rf_confidence||0;
    if(!confByCat[cat]) confByCat[cat]={sum:0,count:0};
    confByCat[cat].sum+=(p.rf_confidence||0);
    confByCat[cat].count++;
  });
  const agreedCount=predHistory.filter(p=>p.agreed&&p.knn_label).length;
  const bothTotal=predHistory.filter(p=>p.knn_label).length;
  return {total,attacks,normals,byCat,byClass,byProto,byFlag,byService,
    rfCount,knnCount,bothCount,totalConf,confByCat,
    agreedCount,bothTotal,avgConf:totalConf/total};
}

// Timeline data — group by minute
function getTimeline() {
  const byMinute={};
  predHistory.slice().reverse().forEach(p=>{
    const d=new Date(p.timestamp);
    const key=`${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
    if(!byMinute[key]) byMinute[key]={normal:0,attack:0};
    if(p.is_attack) byMinute[key].attack++;
    else byMinute[key].normal++;
  });
  return byMinute;
}

// ════════════════════════════════════════════════════════════════
// DASHBOARD REFRESH
// ════════════════════════════════════════════════════════════════
function refreshDashboard() {
  const stats=getSessionStats(); if(!stats) return;
  // KPIs
  setEl('kpi-preds',stats.total);
  setEl('kpi-normal',stats.normals);
  setEl('kpi-attacks',stats.attacks);
  setEl('kpi-rate',(stats.attacks/stats.total*100).toFixed(0)+'%');
  setEl('kpi-rf-count', stats.rfCount+stats.bothCount);
  setEl('kpi-knn-count',stats.knnCount+stats.bothCount);

  // Doughnut — my detections by category
  const cats=Object.keys(stats.byCat);
  const catColors=cats.map(c=>catColor(c));
  destroyChart('myDist');
  const distC=el('chart-my-dist');
  if(distC){ charts.myDist=new Chart(distC,{type:'doughnut',data:{labels:cats,datasets:[{data:cats.map(c=>stats.byCat[c]),backgroundColor:catColors,borderWidth:2,borderColor:document.documentElement.classList.contains('light')?'#fff':'#1e293b'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}}); }
  const legEl=el('legend-my-dist');
  if(legEl) legEl.innerHTML=cats.map((c,i)=>`<div class="legend-item"><div class="legend-dot" style="background:${catColors[i]}"></div>${c} (${stats.byCat[c]})</div>`).join('');

  // Timeline
  const tl=getTimeline();
  const tlLabels=Object.keys(tl);
  destroyChart('timeline');
  const tlC=el('chart-timeline');
  if(tlC&&tlLabels.length) charts.timeline=new Chart(tlC,{type:'bar',data:{labels:tlLabels,datasets:[{label:'Normal',data:tlLabels.map(k=>tl[k].normal),backgroundColor:catColor('Normal')+'aa',borderRadius:3},{label:'Attaque',data:tlLabels.map(k=>tl[k].attack),backgroundColor:catColor('DoS')+'aa',borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:8}}},scales:{x:{ticks:{maxRotation:45}},y:{beginAtZero:true,ticks:{stepSize:1}}}}});

  // Classes frequency
  const classes=Object.keys(stats.byClass).sort((a,b)=>stats.byClass[b]-stats.byClass[a]);
  destroyChart('classFreq');
  const cfC=el('chart-classes-freq');
  if(cfC&&classes.length) charts.classFreq=new Chart(cfC,{type:'bar',data:{labels:classes,datasets:[{label:'Nb détections',data:classes.map(c=>stats.byClass[c]),backgroundColor:classes.map(c=>catColor(ATTACK_MAP[c]||'Unknown')+'bb'),borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{font:{size:10},maxRotation:45}},y:{beginAtZero:true,ticks:{stepSize:1}}}}});

  // Confidence by category
  const confCats=Object.keys(stats.confByCat);
  const avgConfs=confCats.map(c=>(stats.confByCat[c].sum/stats.confByCat[c].count).toFixed(1));
  destroyChart('confByCat');
  const confC=el('chart-confidence');
  if(confC&&confCats.length) charts.confByCat=new Chart(confC,{type:'bar',data:{labels:confCats,datasets:[{label:'Confiance moy. (%)',data:avgConfs,backgroundColor:confCats.map(c=>catColor(c)+'cc'),borderRadius:4}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,max:100,ticks:{callback:v=>v+'%'}}}}});
}

// ════════════════════════════════════════════════════════════════
// PERFORMANCE REFRESH
// ════════════════════════════════════════════════════════════════
function refreshPerformance() {
  const stats=getSessionStats(); if(!stats) return;
  const sub=el('perf-sub');
  if(sub) sub.textContent=`// ${stats.total} analyse(s) effectuée(s) — mis à jour en temps réel`;

  // KPI row
  const kpiRow=el('perf-kpi-row');
  if(kpiRow) kpiRow.innerHTML=`
    <div class="perf-model-card blue" style="flex:1;padding:20px;text-align:center;border-radius:var(--radius-lg);border:1px solid var(--border);background:var(--surface);border-top:3px solid var(--accent)">
      <div class="pm-name">Total analyses</div>
      <div class="pm-acc" style="color:var(--accent)">${stats.total}</div>
      <div class="pm-sub">cette session</div>
    </div>
    <div class="perf-model-card" style="flex:1;padding:20px;text-align:center;border-radius:var(--radius-lg);border:1px solid var(--border);background:var(--surface);border-top:3px solid var(--green)">
      <div class="pm-name">Trafic normal</div>
      <div class="pm-acc" style="color:var(--green)">${stats.normals}</div>
      <div class="pm-sub">${(stats.normals/stats.total*100).toFixed(0)}% du total</div>
    </div>
    <div class="perf-model-card" style="flex:1;padding:20px;text-align:center;border-radius:var(--radius-lg);border:1px solid var(--border);background:var(--surface);border-top:3px solid var(--red)">
      <div class="pm-name">Attaques détectées</div>
      <div class="pm-acc" style="color:var(--red)">${stats.attacks}</div>
      <div class="pm-sub">${(stats.attacks/stats.total*100).toFixed(0)}% du total</div>
    </div>
    <div class="perf-model-card" style="flex:1;padding:20px;text-align:center;border-radius:var(--radius-lg);border:1px solid var(--border);background:var(--surface);border-top:3px solid var(--purple)">
      <div class="pm-name">Confiance moyenne</div>
      <div class="pm-acc" style="color:var(--purple)">${stats.avgConf.toFixed(1)}%</div>
      <div class="pm-sub">RF sur toutes analyses</div>
    </div>`;

  // Doughnut categories
  const cats=Object.keys(stats.byCat);
  destroyChart('perfCat');
  const perfCatC=el('chart-perf-cat');
  if(perfCatC) charts.perfCat=new Chart(perfCatC,{type:'doughnut',data:{labels:cats,datasets:[{data:cats.map(c=>stats.byCat[c]),backgroundColor:cats.map(c=>catColor(c)),borderWidth:2,borderColor:document.documentElement.classList.contains('light')?'#fff':'#1e293b'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:11},padding:8}}}}});
  const legPerfCat=el('legend-perf-cat');
  if(legPerfCat) legPerfCat.innerHTML=cats.map(c=>`<div class="legend-item"><div class="legend-dot" style="background:${catColor(c)}"></div>${c} (${stats.byCat[c]} · ${(stats.byCat[c]/stats.total*100).toFixed(0)}%)</div>`).join('');

  // Confidence histogram
  const confBuckets={60:0,70:0,80:0,90:0,100:0};
  predHistory.forEach(p=>{
    const c=p.rf_confidence||0;
    if(c>=90) confBuckets[100]++;
    else if(c>=80) confBuckets[90]++;
    else if(c>=70) confBuckets[80]++;
    else if(c>=60) confBuckets[70]++;
    else confBuckets[60]++;
  });
  destroyChart('perfConf');
  const perfConfC=el('chart-perf-conf');
  if(perfConfC) charts.perfConf=new Chart(perfConfC,{type:'bar',data:{labels:['<60%','60-70%','70-80%','80-90%','≥90%'],datasets:[{label:'Nb détections',data:Object.values(confBuckets),backgroundColor:['var(--red)','var(--amber)','#94a3b8','var(--accent)','var(--green)'].map(c=>c+'cc'),borderRadius:4}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1}}}}});

  // Classes bar
  const classes=Object.keys(stats.byClass).sort((a,b)=>stats.byClass[b]-stats.byClass[a]);
  destroyChart('perfClasses');
  const perfClC=el('chart-perf-classes');
  if(perfClC) charts.perfClasses=new Chart(perfClC,{type:'bar',data:{labels:classes,datasets:[{label:'Nb fois détecté',data:classes.map(c=>stats.byClass[c]),backgroundColor:classes.map(c=>catColor(ATTACK_MAP[c]||'Unknown')+'cc'),borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{font:{size:10},maxRotation:45}},y:{beginAtZero:true,ticks:{stepSize:1}}}}});

  // Model agreement panel
  const agreePanel=el('model-agreement-panel');
  if(agreePanel){
    const bothTotal=predHistory.filter(p=>p.knn_label).length;
    const agreed=predHistory.filter(p=>p.agreed&&p.knn_label).length;
    agreePanel.innerHTML=`
      <div class="agreement-stat"><span>Analyses RF seul</span><div class="agreement-val" style="color:var(--accent)">${stats.rfCount}</div></div>
      <div class="agreement-stat"><span>Analyses KNN seul</span><div class="agreement-val" style="color:var(--purple)">${stats.knnCount}</div></div>
      <div class="agreement-stat"><span>Comparaison RF+KNN</span><div class="agreement-val">${stats.bothCount}</div></div>
      ${bothTotal>0?`<div class="agreement-stat"><span>Accord RF=KNN</span><div class="agreement-val" style="color:var(--green)">${agreed}/${bothTotal} (${(agreed/bothTotal*100).toFixed(0)}%)</div></div>`:'<div style="font-family:var(--mono);font-size:11px;color:var(--text3);padding:12px">Aucune comparaison RF+KNN encore effectuée</div>'}`;
  }

  // Timeline
  const tl=getTimeline();
  const tlLabels=Object.keys(tl);
  destroyChart('perfTimeline');
  const perfTlC=el('chart-perf-timeline');
  if(perfTlC&&tlLabels.length) charts.perfTimeline=new Chart(perfTlC,{type:'line',data:{labels:tlLabels,datasets:[{label:'Normal',data:tlLabels.map(k=>tl[k].normal),borderColor:catColor('Normal'),backgroundColor:catColor('Normal')+'20',tension:0.3,fill:true},{label:'Attaque',data:tlLabels.map(k=>tl[k].attack),borderColor:catColor('DoS'),backgroundColor:catColor('DoS')+'20',tension:0.3,fill:true}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:8}}},scales:{y:{beginAtZero:true,ticks:{stepSize:1}}}}});

  // Session table
  const tbody=el('session-results-tbody');
  if(tbody) tbody.innerHTML=predHistory.map(p=>`<tr>
    <td style="color:var(--text3)">${p.id}</td>
    <td>${p.time}</td>
    <td>${p.protocol}</td>
    <td style="color:var(--text3)">${p.service}</td>
    <td style="color:var(--text3)">${p.flag}</td>
    <td>${p.src_bytes.toLocaleString()}</td>
    <td style="color:var(--text3)">${p.model_used}</td>
    <td style="color:${catColor(p.rf_category)};font-weight:500">${p.rf_label}</td>
    <td><span class="badge-cat badge-${p.rf_category}">${p.rf_category}</span></td>
    <td>${(p.rf_confidence||0).toFixed(1)}%</td>
  </tr>`).join('');
}

// ════════════════════════════════════════════════════════════════
// RESULTS TABLE — classes prédites
// ════════════════════════════════════════════════════════════════
function refreshResultsTable() {
  const stats=getSessionStats(); if(!stats) return;
  const search=((el('class-search')||{}).value||'').toLowerCase();

  // Build class-level aggregates
  const classData={};
  predHistory.forEach(p=>{
    const cls=p.rf_label;
    if(!classData[cls]) classData[cls]={
      class:cls, category:p.rf_category, count:0,
      confs:[], lastTime:p.time, protocol:new Set(), service:new Set(), models:new Set()
    };
    classData[cls].count++;
    classData[cls].confs.push(p.rf_confidence||0);
    classData[cls].lastTime=p.time;
    classData[cls].protocol.add(p.protocol);
    classData[cls].service.add(p.service);
    classData[cls].models.add(p.model_used);
  });

  let rows=Object.values(classData).sort((a,b)=>b.count-a.count);
  if(search) rows=rows.filter(r=>r.class.toLowerCase().includes(search)||r.category.toLowerCase().includes(search));

  // Summary cards
  const summCards=el('class-summary-cards');
  if(summCards) summCards.innerHTML=rows.slice(0,6).map(r=>{
    const avg=(r.confs.reduce((a,b)=>a+b,0)/r.confs.length).toFixed(1);
    return`<div class="rsm-card"><div class="rsm-label" style="color:${catColor(r.category)}">${r.category}</div><div class="rsm-val" style="color:${catColor(r.category)}">${r.class}</div><div class="rsm-sub">${r.count}x · conf. ${avg}%</div></div>`;
  }).join('');

  // Main table
  const tbody=el('class-tbody');
  if(tbody) tbody.innerHTML=rows.map(r=>{
    const avg=r.confs.reduce((a,b)=>a+b,0)/r.confs.length;
    const mn=Math.min(...r.confs), mx=Math.max(...r.confs);
    const pct=(r.count/predHistory.length*100).toFixed(0);
    const barW=Math.max(4,r.count/predHistory.length*100);
    return`<tr>
      <td style="font-weight:500;color:var(--text)">${r.class}</td>
      <td><span class="badge-cat badge-${r.category}">${r.category}</span></td>
      <td><div class="tbl-bar-wrap"><div class="tbl-bar-track"><div class="tbl-bar-fill" style="width:${barW}%;background:${catColor(r.category)};opacity:.75"></div></div><div class="tbl-val">${r.count}</div></div></td>
      <td style="color:var(--accent)">${pct}%</td>
      <td style="font-weight:500">${avg.toFixed(1)}%</td>
      <td style="color:var(--text3)">${mn.toFixed(1)}%</td>
      <td style="color:var(--text3)">${mx.toFixed(1)}%</td>
      <td style="color:var(--text3);font-size:10px">${[...r.models].join(', ')}</td>
      <td style="color:var(--text3)">${r.lastTime}</td>
    </tr>`;
  }).join('');

  // Heatmap
  const heatmap=el('detection-heatmap');
  if(heatmap) heatmap.innerHTML=`<div class="heatmap-grid">${rows.map(r=>{
    const w=Math.max(20,r.count/rows[0].count*100);
    return`<div class="heatmap-row"><div class="heatmap-label">${r.class}</div><div class="heatmap-rf" style="width:${w}%;background:${catColor(r.category)};color:#fff">${r.count}x</div></div>`;
  }).join('')}</div>`;

  // Distribution bar chart
  destroyChart('classDist');
  const distC=el('chart-class-dist');
  if(distC) charts.classDist=new Chart(distC,{type:'bar',data:{labels:rows.map(r=>r.class),datasets:[{label:'Fois détecté',data:rows.map(r=>r.count),backgroundColor:rows.map(r=>catColor(r.category)+'bb'),borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{font:{size:10},maxRotation:45}},y:{beginAtZero:true,ticks:{stepSize:1}}}}});
}
window.renderClassSummary = refreshResultsTable;

// ════════════════════════════════════════════════════════════════
// FEATURES — basées sur VOS connexions
// ════════════════════════════════════════════════════════════════
function refreshFeatures() {
  const stats=getSessionStats(); if(!stats) return;

  // Protocol pie
  destroyChart('featProto');
  const protoC=el('chart-feat-proto');
  if(protoC){
    const protos=Object.keys(stats.byProto);
    charts.featProto=new Chart(protoC,{type:'pie',data:{labels:protos,datasets:[{data:protos.map(p=>stats.byProto[p]),backgroundColor:['#38bdf8','#a78bfa','#fbbf24','#34d399'].slice(0,protos.length),borderWidth:2,borderColor:document.documentElement.classList.contains('light')?'#fff':'#1e293b'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:11},padding:8}}}}});
  }

  // Flag bar
  destroyChart('featFlag');
  const flagC=el('chart-feat-flag');
  if(flagC){
    const flags=Object.entries(stats.byFlag).sort((a,b)=>b[1]-a[1]);
    charts.featFlag=new Chart(flagC,{type:'bar',data:{labels:flags.map(f=>f[0]),datasets:[{label:'Nb analyses',data:flags.map(f=>f[1]),backgroundColor:'#38bdf8bb',borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1}}}}});
  }

  // Service bar
  destroyChart('featService');
  const svcC=el('chart-feat-service');
  if(svcC){
    const svcs=Object.entries(stats.byService).sort((a,b)=>b[1]-a[1]).slice(0,10);
    charts.featService=new Chart(svcC,{type:'bar',data:{labels:svcs.map(s=>s[0]),datasets:[{label:'Nb analyses',data:svcs.map(s=>s[1]),backgroundColor:'#a78bfabb',borderRadius:3}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{maxRotation:45,font:{size:10}}},y:{beginAtZero:true,ticks:{stepSize:1}}}}});
  }

  // Src vs Dst bytes scatter
  destroyChart('featBytes');
  const bytesC=el('chart-feat-bytes');
  if(bytesC){
    const pts=predHistory.map(p=>({x:Math.min(p.src_bytes,100000),y:Math.min(p.dst_bytes,100000),cat:p.rf_category,label:p.rf_label}));
    const cats=[...new Set(pts.map(p=>p.cat))];
    charts.featBytes=new Chart(bytesC,{type:'scatter',data:{datasets:cats.map(cat=>({label:cat,data:pts.filter(p=>p.cat===cat).map(p=>({x:p.x,y:p.y,label:p.label})),backgroundColor:catColor(cat)+'cc',pointRadius:6,pointHoverRadius:9}))},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:8}},tooltip:{callbacks:{label:ctx=>`${ctx.raw.label}: src=${ctx.raw.x.toLocaleString()} dst=${ctx.raw.y.toLocaleString()}`}}},scales:{x:{title:{display:true,text:'Src bytes (cap 100k)'},ticks:{callback:v=>v>=1000?Math.round(v/1000)+'k':v}},y:{title:{display:true,text:'Dst bytes (cap 100k)'},ticks:{callback:v=>v>=1000?Math.round(v/1000)+'k':v}}}}});
  }

  // Serror rate vs same srv rate scatter
  destroyChart('featRates');
  const ratesC=el('chart-feat-rates');
  if(ratesC){
    const rpts=predHistory.map(p=>({x:parseFloat(p.serror_rate)||0,y:parseFloat(p.same_srv_rate)||0,cat:p.rf_category,label:p.rf_label}));
    const rcats=[...new Set(rpts.map(p=>p.cat))];
    charts.featRates=new Chart(ratesC,{type:'scatter',data:{datasets:rcats.map(cat=>({label:cat,data:rpts.filter(p=>p.cat===cat).map(p=>({x:p.x,y:p.y,label:p.label})),backgroundColor:catColor(cat)+'cc',pointRadius:6,pointHoverRadius:9}))},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:10},padding:8}},tooltip:{callbacks:{label:ctx=>`${ctx.raw.label}: se=${ctx.raw.x.toFixed(2)} ssr=${ctx.raw.y.toFixed(2)}`}}},scales:{x:{title:{display:true,text:'Serror rate'},min:0,max:1},y:{title:{display:true,text:'Same srv rate'},min:0,max:1}}}});
  }
}

// ════════════════════════════════════════════════════════════════
// HISTORY TAB
// ════════════════════════════════════════════════════════════════
function renderHistory(filterCat='') {
  const emptyEl=el('hist-empty'), tableEl=el('hist-table'), tbodyEl=el('hist-tbody');
  if(!emptyEl||!tableEl) return;
  let items=predHistory;
  if(filterCat) items=items.filter(p=>p.rf_category===filterCat);
  const normals=predHistory.filter(p=>!p.is_attack).length;
  const attacks=predHistory.filter(p=>p.is_attack).length;
  setEl('hs-normal',normals); setEl('hs-attack',attacks);
  setEl('hs-rate',predHistory.length>0?(attacks/predHistory.length*100).toFixed(0)+'%':'0%');
  // Summary cards
  const summCards=el('hist-summary-cards');
  if(summCards){
    const total=predHistory.length;
    const byCat={};
    predHistory.forEach(p=>{byCat[p.rf_category]=(byCat[p.rf_category]||0)+1;});
    summCards.innerHTML=`
      <div class="rsm-card"><div class="rsm-label">Total</div><div class="rsm-val">${total}</div><div class="rsm-sub">analyses</div></div>
      <div class="rsm-card"><div class="rsm-label">Normales</div><div class="rsm-val" style="color:var(--green)">${normals}</div><div class="rsm-sub">${total?Math.round(normals/total*100):0}%</div></div>
      <div class="rsm-card"><div class="rsm-label">Attaques</div><div class="rsm-val" style="color:var(--red)">${attacks}</div><div class="rsm-sub">${total?Math.round(attacks/total*100):0}%</div></div>
      <div class="rsm-card"><div class="rsm-label">Classes uniques</div><div class="rsm-val">${new Set(predHistory.map(p=>p.rf_label)).size}</div><div class="rsm-sub">détectées</div></div>`;
  }
  if(!items.length){emptyEl.style.display='block';tableEl.style.display='none';return;}
  emptyEl.style.display='none'; tableEl.style.display='table';
  if(tbodyEl) tbodyEl.innerHTML=items.map(p=>`<tr>
    <td style="color:var(--text3)">${p.id}</td>
    <td>${p.time}</td>
    <td><span style="padding:1px 6px;background:var(--surface2);border-radius:3px;font-size:10px">${p.protocol}</span></td>
    <td style="color:var(--text3)">${p.service}</td>
    <td style="color:var(--text3)">${p.flag}</td>
    <td>${p.src_bytes.toLocaleString()}</td>
    <td>${(p.dst_bytes||0).toLocaleString()}</td>
    <td style="color:var(--text3)">${p.count||0}</td>
    <td style="color:var(--text3)">${(p.serror_rate||0).toFixed(2)}</td>
    <td style="color:var(--text3)">${p.model_used}</td>
    <td style="font-weight:500;color:${catColor(p.rf_category)}">${p.rf_label}</td>
    <td><span class="badge-cat badge-${p.rf_category}">${p.rf_category}</span></td>
    <td>${(p.rf_confidence||0).toFixed(1)}%</td>
  </tr>`).join('');
}
const histFilter=el('hist-filter');
if(histFilter) histFilter.addEventListener('change',e=>renderHistory(e.target.value));
const btnClear=el('btn-clear-hist');
if(btnClear) btnClear.addEventListener('click',async()=>{
  predHistory=[]; alertCount=0; hasDetected=false;
  setEl('alert-count','0'); setEl('kpi-preds','0');
  setEl('kpi-normal','0'); setEl('kpi-attacks','0');
  setEl('kpi-rate','0%'); setEl('kpi-rf-count','0'); setEl('kpi-knn-count','0');
  setHtml('alert-feed','<div class="feed-empty">--</div>');
  renderHistory();
  // Hide charts, show waiting screens
  ['dash-waiting','perf-waiting','results-waiting','features-waiting','report-waiting'].forEach(id=>{const e=el(id);if(e)e.style.display='flex';});
  ['dash-charts','perf-content','results-content','features-content','report-content'].forEach(id=>{const e=el(id);if(e)e.style.display='none';});
  const badge=el('live-badge');if(badge)badge.textContent='EN ATTENTE';
  document.querySelectorAll('.nav-item').forEach(item=>{if(LOCKED.includes(item.dataset.tab))item.classList.add('nav-locked');});
  if(apiOnline){try{await fetch(`${API}/api/history`,{method:'DELETE'});}catch{}}
});

// ════════════════════════════════════════════════════════════════
// RAPPORT SESSION
// ════════════════════════════════════════════════════════════════
function refreshReport() {
  const stats=getSessionStats(); if(!stats) return;
  const now=new Date().toLocaleString('fr-FR');
  const classes=Object.keys(predHistory.reduce((a,p)=>{a[p.rf_label]=(a[p.rf_label]||0)+1;return a;},{}));
  const uniqueCats=[...new Set(predHistory.map(p=>p.rf_category))];
  const avgConf=(predHistory.reduce((a,p)=>a+(p.rf_confidence||0),0)/predHistory.length).toFixed(1);
  const lastLabel=predHistory[0]?.rf_label||'-';
  const lastCat=predHistory[0]?.rf_category||'-';

  setHtml('report-content',`
    <div class="report-section">
      <div class="report-h2">Rapport de session IDS — <span>${now}</span></div>
      <p class="report-p">Rapport automatique basé sur <strong>${stats.total} analyse(s)</strong> effectuée(s) dans cette session sur le système IDS NSL-KDD.</p>
      <div class="report-grid">
        <div class="report-metric"><div class="report-metric-label">Analyses effectuées</div><div class="report-metric-val">${stats.total}</div><div class="report-metric-sub">cette session</div></div>
        <div class="report-metric"><div class="report-metric-label">Trafic normal</div><div class="report-metric-val" style="color:var(--green)">${stats.normals}</div><div class="report-metric-sub">${(stats.normals/stats.total*100).toFixed(0)}%</div></div>
        <div class="report-metric"><div class="report-metric-label">Attaques détectées</div><div class="report-metric-val" style="color:var(--red)">${stats.attacks}</div><div class="report-metric-sub">${(stats.attacks/stats.total*100).toFixed(0)}%</div></div>
        <div class="report-metric"><div class="report-metric-label">Classes uniques</div><div class="report-metric-val">${classes.length}</div><div class="report-metric-sub">types différents</div></div>
        <div class="report-metric"><div class="report-metric-label">Confiance moyenne</div><div class="report-metric-val">${avgConf}%</div><div class="report-metric-sub">RF</div></div>
        <div class="report-metric"><div class="report-metric-label">Dernière détection</div><div class="report-metric-val" style="font-size:14px">${lastLabel}</div><div class="report-metric-sub">${lastCat}</div></div>
      </div>
    </div>

    <div class="report-section">
      <div class="report-h2">Catégories <span>détectées</span></div>
      <table class="report-table">
        <thead><tr><th>Catégorie</th><th>Nb détections</th><th>% du total</th><th>Classes vues</th></tr></thead>
        <tbody>${uniqueCats.map(cat=>{
          const cnt=stats.byCat[cat]||0;
          const cls=[...new Set(predHistory.filter(p=>p.rf_category===cat).map(p=>p.rf_label))].join(', ');
          return`<tr><td><span class="badge-cat badge-${cat}">${cat}</span></td><td style="font-weight:500">${cnt}</td><td style="color:var(--accent)">${(cnt/stats.total*100).toFixed(0)}%</td><td style="color:var(--text3);font-size:10px">${cls}</td></tr>`;
        }).join('')}</tbody>
      </table>
    </div>

    <div class="report-section">
      <div class="report-h2">Détail des <span>${predHistory.length} analyses</span></div>
      <table class="report-table">
        <thead><tr><th>#</th><th>Heure</th><th>Proto</th><th>Service</th><th>Classe RF</th><th>Catégorie</th><th>Conf.</th><th>Modèle</th></tr></thead>
        <tbody>${predHistory.slice(0,20).map(p=>`<tr><td style="color:var(--text3)">${p.id}</td><td>${p.time}</td><td>${p.protocol}</td><td style="color:var(--text3)">${p.service}</td><td style="color:${catColor(p.rf_category)};font-weight:500">${p.rf_label}</td><td><span class="badge-cat badge-${p.rf_category}">${p.rf_category}</span></td><td>${(p.rf_confidence||0).toFixed(1)}%</td><td style="color:var(--text3)">${p.model_used}</td></tr>`).join('')}</tbody>
      </table>
      ${predHistory.length>20?`<div style="font-family:var(--mono);font-size:11px;color:var(--text3);padding:10px 0">... et ${predHistory.length-20} analyse(s) supplémentaire(s) — allez dans Historique pour voir toutes</div>`:''}
    </div>

    <div class="report-section">
      <div class="report-h2">Analyse <span>de la session</span></div>
      <p class="report-p">Sur vos ${stats.total} analyse(s), ${stats.attacks} ont été identifiées comme attaques (${(stats.attacks/stats.total*100).toFixed(0)}%). Le trafic légitime représente ${(stats.normals/stats.total*100).toFixed(0)}% de vos analyses.</p>
      ${stats.attacks>0?`<div class="report-conclusion"><strong>Attention :</strong> ${stats.attacks} connexion(s) suspecte(s) détectée(s) sur ${stats.total} analyse(s). Les catégories impliquées : ${Object.entries(stats.byCat).filter(([k])=>k!=='Normal').map(([k,v])=>`${k} (${v}x)`).join(', ')||'—'}.</div>`:`<div class="report-conclusion" style="border-color:var(--green)"><strong>Réseau sain :</strong> Toutes vos analyses sont classées comme trafic normal. Aucune intrusion détectée.</div>`}
    </div>`);
}

// ════════════════════════════════════════════════════════════════
// EXPORT
// ════════════════════════════════════════════════════════════════
function downloadCSV(content, filename) {
  const blob=new Blob([content],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download=filename; a.click(); URL.revokeObjectURL(a.href);
}
window.exportSessionCSV = function(){
  if(!predHistory.length){ alert('Aucune analyse à exporter.'); return; }
  let csv='ID,Heure,Protocole,Service,Flag,Src_bytes,Dst_bytes,Count,Serror_rate,Same_srv_rate,Diff_srv_rate,Modèle,Classe_RF,Catégorie_RF,Conf_RF,Classe_KNN,Catégorie_KNN,Conf_KNN,Accord\n';
  predHistory.forEach(p=>{
    csv+=`${p.id},${p.time},${p.protocol},${p.service},${p.flag},${p.src_bytes},${p.dst_bytes||0},${p.count||0},${p.serror_rate||0},${p.same_srv_rate||0},${p.diff_srv_rate||0},${p.model_used},${p.rf_label},${p.rf_category},${(p.rf_confidence||0).toFixed(1)}%,${p.knn_label||''},${p.knn_category||''},${p.knn_confidence?p.knn_confidence.toFixed(1)+'%':''},${p.agreed}\n`;
  });
  downloadCSV(csv,'ids_session_'+new Date().toISOString().slice(0,10)+'.csv');
};

function showError(msg) {
  const card=el('result-card'); if(!card) return;
  card.style.display='block';
  card.innerHTML=`<div style="color:var(--red);padding:14px;font-family:var(--mono)"><strong>ERREUR :</strong> ${msg}</div>`;
}

// ════════════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════════════
async function init() {
  try{
    const resp=await fetch(`${API}/api/health`,{signal:AbortSignal.timeout(3000)});
    const data=await resp.json(); apiOnline=data.status==='ok';
  }catch{ apiOnline=false; }
  const dot=el('status-dot'), txt=el('status-text');
  if(dot) dot.className='status-dot '+(apiOnline?'online':'offline');
  if(txt) txt.textContent=apiOnline?'API connectée':'Mode local';

  // Theme icon
  const saved=localStorage.getItem('ids-theme')||'dark';
  const icon=el('theme-icon'), label=el('theme-label');
  if(saved==='light'){if(icon)icon.textContent='Light';if(label)label.textContent='Light mode';}
  else{if(icon)icon.textContent='Dark';if(label)label.textContent='Dark mode';}

  // All tabs locked initially
  LOCKED.forEach(tab=>{
    const item=document.querySelector(`[data-tab="${tab}"]`);
    if(item) item.classList.add('nav-locked');
  });
}

init();
