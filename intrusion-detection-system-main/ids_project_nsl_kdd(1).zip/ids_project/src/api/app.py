"""
API Flask pour le système IDS
Routes : /predict, /predict_both, /metrics, /history, /health
"""
from flask import Flask, request, jsonify, render_template, abort
from flask_cors import CORS
from datetime import datetime
import os, sys, json

# Chemin racine du projet (2 niveaux au-dessus de src/api/)
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT_DIR)

from config import API_HOST, API_PORT, DEBUG, MODELS_DIR
from src.models.predictor import IDSPredictor

app = Flask(__name__,
            template_folder=os.path.join(ROOT_DIR, 'templates'),
            static_folder=os.path.join(ROOT_DIR, 'static'))
CORS(app)

# Chargement global du prédicteur
predictor = None
prediction_history = []


def get_predictor():
    global predictor
    if predictor is None:
        predictor = IDSPredictor(MODELS_DIR)
    return predictor


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Page principale du tableau de bord."""
    return render_template('index.html')

@app.route('/api/health', methods=['GET'])
def health():
    """Vérification de l'état du service."""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'models_loaded': predictor is not None,
        'predictions_made': len(prediction_history)
    })

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Prédit la classe d'une connexion réseau.
    Body JSON : features de la connexion + champ 'model' ('rf' ou 'knn')
    """
    data = request.get_json(force=True)
    if not data:
        abort(400, description="Corps JSON requis")

    model = data.pop('model', 'rf')
    if model not in ('rf', 'knn'):
        abort(400, description="model doit être 'rf' ou 'knn'")

    try:
        result = get_predictor().predict(data, model=model)
        result['timestamp'] = datetime.now().isoformat()
        result['input_features'] = data

        # Sauvegarder dans l'historique
        prediction_history.append({
            'id': len(prediction_history) + 1,
            'timestamp': result['timestamp'],
            'model': model.upper(),
            'label': result['predicted_label'],
            'category': result['category'],
            'confidence': result['confidence'],
            'is_attack': result['is_attack'],
            'protocol': data.get('protocol_type', '?'),
            'src_bytes': data.get('src_bytes', 0),
            'dst_bytes': data.get('dst_bytes', 0),
        })

        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict_both', methods=['POST'])
def predict_both():
    """
    Lance RF et KNN en parallèle sur la même connexion et compare.
    """
    data = request.get_json(force=True)
    if not data:
        abort(400, description="Corps JSON requis")
    try:
        result = get_predictor().predict_both(data)
        result['timestamp'] = datetime.now().isoformat()
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/metrics', methods=['GET'])
def metrics():
    """Retourne les métriques de performance des deux modèles."""
    try:
        m = get_predictor().get_metrics()
        return jsonify(m)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history', methods=['GET'])
def history():
    """
    Retourne l'historique des prédictions.
    Query params : limit (défaut 50), category (filtre)
    """
    limit = int(request.args.get('limit', 50))
    category = request.args.get('category', None)
    items = prediction_history[::-1]  # Plus récent en premier
    if category:
        items = [i for i in items if i['category'] == category]
    return jsonify({
        'total': len(prediction_history),
        'items': items[:limit]
    })


@app.route('/api/history', methods=['DELETE'])
def clear_history():
    """Efface l'historique des prédictions."""
    global prediction_history
    prediction_history = []
    return jsonify({'message': 'Historique effacé'})


@app.route('/api/history/stats', methods=['GET'])
def history_stats():
    """Statistiques agrégées sur l'historique."""
    if not prediction_history:
        return jsonify({'total': 0, 'by_category': {}, 'attack_rate': 0})
    by_cat = {}
    attacks = 0
    for p in prediction_history:
        cat = p['category']
        by_cat[cat] = by_cat.get(cat, 0) + 1
        if p['is_attack']:
            attacks += 1
    return jsonify({
        'total': len(prediction_history),
        'by_category': by_cat,
        'attack_rate': round(attacks / len(prediction_history) * 100, 2),
        'attacks': attacks,
        'normal': len(prediction_history) - attacks
    })


@app.errorhandler(400)
def bad_request(e):
    return jsonify({'error': str(e)}), 400

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Route non trouvée'}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Erreur serveur interne'}), 500


if __name__ == '__main__':
    print("="*50)
    print("  Démarrage IDS Flask API")
    print(f"  ROOT      : {ROOT_DIR}")
    print(f"  Templates : {os.path.join(ROOT_DIR, 'templates')}")
    print(f"  Static    : {os.path.join(ROOT_DIR, 'static')}")
    print(f"  URL : http://localhost:{API_PORT}")
    print("="*50)
    get_predictor()
    app.run(host=API_HOST, port=API_PORT, debug=DEBUG)
