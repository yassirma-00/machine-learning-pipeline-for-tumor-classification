"""
Module de prétraitement des données NSL-KDD
Étape 1 : Chargement, nettoyage, encodage, normalisation
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import COLUMNS, ATTACK_CATEGORIES


def load_dataset(filepath: str) -> pd.DataFrame:
    """
    Charge un fichier NSL-KDD (.txt) et retourne un DataFrame avec les noms de colonnes.
    """
    df = pd.read_csv(filepath, header=None, names=COLUMNS)
    df = df.drop(columns=['difficulty'], errors='ignore')
    print(f"  [✓] Chargé : {filepath} → {df.shape[0]} lignes, {df.shape[1]} colonnes")
    return df


def map_attack_categories(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ajoute une colonne 'category' qui regroupe les attaques en 5 catégories :
    Normal, DoS, Probe, R2L, U2R.
    """
    df = df.copy()
    df['category'] = df['label'].map(lambda x: ATTACK_CATEGORIES.get(x, 'Unknown'))
    return df


def encode_categorical(train_df: pd.DataFrame,
                        test_df: pd.DataFrame,
                        cat_cols: list = None) -> tuple:
    """
    Encode les variables catégorielles avec LabelEncoder.
    Retourne : (train_df, test_df, encoders_dict)
    """
    if cat_cols is None:
        cat_cols = ['protocol_type', 'service', 'flag']

    train_df = train_df.copy()
    test_df = test_df.copy()
    encoders = {}

    for col in cat_cols:
        le = LabelEncoder()
        # Fit sur l'union des deux jeux pour éviter les valeurs inconnues
        all_values = pd.concat([train_df[col], test_df[col]]).unique()
        le.fit(all_values)
        train_df[col] = le.transform(train_df[col])
        test_df[col] = le.transform(test_df[col])
        encoders[col] = le
        print(f"  [✓] Encodage '{col}' : {len(le.classes_)} classes")

    return train_df, test_df, encoders


def encode_single(df: pd.DataFrame,
                   encoders: dict,
                   cat_cols: list = None) -> pd.DataFrame:
    """
    Encode un seul DataFrame (ex: données de test en production)
    à partir des encodeurs déjà ajustés.
    """
    if cat_cols is None:
        cat_cols = ['protocol_type', 'service', 'flag']
    df = df.copy()
    for col in cat_cols:
        if col in encoders:
            le = encoders[col]
            # Gérer les valeurs inconnues
            df[col] = df[col].apply(
                lambda x: le.transform([x])[0] if x in le.classes_ else 0
            )
    return df


def split_features_labels(df: pd.DataFrame,
                            label_col: str = 'label',
                            drop_cols: list = None) -> tuple:
    """
    Sépare les features (X) des étiquettes (y et y_cat).
    Retourne : (X, y_label, y_category)
    """
    if drop_cols is None:
        drop_cols = [label_col, 'category']

    existing_drop = [c for c in drop_cols if c in df.columns]
    X = df.drop(columns=existing_drop)
    y = df[label_col] if label_col in df.columns else None
    y_cat = df['category'] if 'category' in df.columns else None
    return X, y, y_cat


def normalize(X_train: np.ndarray,
               X_test: np.ndarray) -> tuple:
    """
    Normalise avec StandardScaler ajusté sur X_train uniquement.
    Retourne : (X_train_scaled, X_test_scaled, scaler)
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    print(f"  [✓] Normalisation : mean~0, std~1 appliquée")
    return X_train_scaled, X_test_scaled, scaler


def get_class_distribution(df: pd.DataFrame, col: str = 'label') -> dict:
    """Retourne la distribution des classes sous forme de dictionnaire."""
    return df[col].value_counts().to_dict()


def full_pipeline(train_path: str,
                   test_path: str) -> dict:
    """
    Pipeline complet de prétraitement.
    Retourne un dictionnaire avec toutes les données prêtes pour l'entraînement.
    """
    print("\n" + "="*55)
    print("  ÉTAPE 1 : PRÉTRAITEMENT DES DONNÉES")
    print("="*55)

    # 1. Chargement
    print("\n[1.1] Chargement des données...")
    train_df = load_dataset(train_path)
    test_df = load_dataset(test_path)

    # 2. Mapping catégories
    print("\n[1.2] Mapping des catégories d'attaques...")
    train_df = map_attack_categories(train_df)
    test_df = map_attack_categories(test_df)

    # 3. Encodage
    print("\n[1.3] Encodage des variables catégorielles...")
    train_df, test_df, encoders = encode_categorical(train_df, test_df)

    # 4. Séparation X/y
    print("\n[1.4] Séparation features / étiquettes...")
    X_train, y_train, y_train_cat = split_features_labels(train_df)
    X_test, y_test, y_test_cat = split_features_labels(test_df)
    feature_names = X_train.columns.tolist()
    print(f"  [✓] {len(feature_names)} features extraites")

    # 5. Normalisation
    print("\n[1.5] Normalisation des données...")
    X_train_scaled, X_test_scaled, scaler = normalize(
        X_train.values, X_test.values
    )

    # Statistiques
    print("\n[1.6] Statistiques des données :")
    print(f"  Train : {X_train_scaled.shape[0]} échantillons")
    print(f"  Test  : {X_test_scaled.shape[0]} échantillons")
    print(f"  Classes train : {sorted(y_train.unique())}")
    print(f"  Répartition catégories train :")
    for cat, cnt in get_class_distribution(train_df, 'category').items():
        pct = cnt / len(train_df) * 100
        print(f"    {cat:10s} : {cnt:7,d} ({pct:.1f}%)")

    return {
        'X_train': X_train_scaled,
        'X_test': X_test_scaled,
        'y_train': y_train,
        'y_test': y_test,
        'y_train_cat': y_train_cat,
        'y_test_cat': y_test_cat,
        'feature_names': feature_names,
        'scaler': scaler,
        'encoders': encoders,
        'train_df': train_df,
        'test_df': test_df,
    }
