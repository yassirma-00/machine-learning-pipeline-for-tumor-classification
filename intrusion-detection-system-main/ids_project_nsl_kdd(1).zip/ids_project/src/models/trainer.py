"""
Module d'entraînement des modèles Random Forest et KNN
Étape 2 : Entraînement, évaluation, sauvegarde
"""
import numpy as np
import json
import os
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, f1_score, precision_score, recall_score
)
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import RF_PARAMS, KNN_PARAMS, KNN_TRAIN_SUBSET, ATTACK_CATEGORIES, MODELS_DIR


def train_random_forest(X_train: np.ndarray,
                         y_train,
                         params: dict = None) -> RandomForestClassifier:
    """
    Entraîne un Random Forest sur les données d'entraînement.
    """
    if params is None:
        params = RF_PARAMS
    print("\n[2.1] Entraînement Random Forest...")
    print(f"  Paramètres : {params}")
    clf = RandomForestClassifier(**params)
    clf.fit(X_train, y_train)
    print(f"  [✓] Random Forest entraîné sur {X_train.shape[0]} échantillons")
    return clf


def train_knn(X_train: np.ndarray,
               y_train,
               params: dict = None,
               subset_size: int = None) -> KNeighborsClassifier:
    """
    Entraîne un classificateur KNN.
    Utilise un sous-ensemble pour la performance.
    """
    if params is None:
        params = KNN_PARAMS
    if subset_size is None:
        subset_size = KNN_TRAIN_SUBSET

    n = min(subset_size, X_train.shape[0])
    print(f"\n[2.2] Entraînement KNN (sous-ensemble: {n:,} échantillons)...")
    print(f"  Paramètres : {params}")
    clf = KNeighborsClassifier(**params)
    clf.fit(X_train[:n], y_train[:n])
    print(f"  [✓] KNN entraîné")
    return clf


def evaluate_model(clf,
                    X_test: np.ndarray,
                    y_test,
                    y_test_cat,
                    model_name: str) -> dict:
    """
    Évalue un modèle et retourne un dictionnaire complet de métriques.
    """
    print(f"\n[2.3] Évaluation {model_name}...")
    preds = clf.predict(X_test)
    cat_preds = [ATTACK_CATEGORIES.get(p, 'Unknown') for p in preds]

    acc = accuracy_score(y_test, preds)
    cat_acc = accuracy_score(y_test_cat, cat_preds)
    f1_macro = f1_score(y_test, preds, average='macro', zero_division=0)
    f1_weighted = f1_score(y_test, preds, average='weighted', zero_division=0)

    report = classification_report(y_test, preds, output_dict=True, zero_division=0)
    cat_report = classification_report(y_test_cat, cat_preds, output_dict=True, zero_division=0)

    cat_labels = sorted(set(y_test_cat.unique()))
    cm = confusion_matrix(y_test_cat, cat_preds, labels=cat_labels).tolist()

    print(f"  Accuracy (label)    : {acc:.4f}")
    print(f"  Accuracy (catégorie): {cat_acc:.4f}")
    print(f"  F1 macro            : {f1_macro:.4f}")
    print(f"  F1 weighted         : {f1_weighted:.4f}")

    return {
        'accuracy': float(acc),
        'cat_accuracy': float(cat_acc),
        'f1_macro': float(f1_macro),
        'f1_weighted': float(f1_weighted),
        'report': report,
        'cat_report': cat_report,
        'confusion_matrix': cm,
        'cm_labels': cat_labels,
        'predictions': preds.tolist(),
        'cat_predictions': cat_preds,
    }


def get_feature_importances(clf: RandomForestClassifier,
                              feature_names: list) -> list:
    """
    Retourne les importances de features triées (RF uniquement).
    """
    if not hasattr(clf, 'feature_importances_'):
        return []
    imp = clf.feature_importances_
    pairs = sorted(zip(feature_names, imp.tolist()), key=lambda x: x[1], reverse=True)
    return pairs


def save_artifacts(rf, knn, scaler, encoders,
                    metrics: dict, feature_names: list,
                    output_dir: str = None):
    """
    Sauvegarde tous les artefacts du projet (modèles + métadonnées).
    """
    if output_dir is None:
        output_dir = MODELS_DIR
    os.makedirs(output_dir, exist_ok=True)

    print("\n[2.4] Sauvegarde des artefacts...")
    joblib.dump(rf, os.path.join(output_dir, "rf_model.joblib"))
    print("  [✓] rf_model.joblib")
    joblib.dump(knn, os.path.join(output_dir, "knn_model.joblib"))
    print("  [✓] knn_model.joblib")
    joblib.dump(scaler, os.path.join(output_dir, "scaler.joblib"))
    print("  [✓] scaler.joblib")
    joblib.dump(encoders, os.path.join(output_dir, "encoders.joblib"))
    print("  [✓] encoders.joblib")

    # Sérialiser les metrics (convertir numpy types)
    def to_python(obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating,)): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return obj

    safe_metrics = json.loads(json.dumps(metrics, default=to_python))
    with open(os.path.join(output_dir, "metrics.json"), 'w', encoding='utf-8') as f:
        json.dump(safe_metrics, f, indent=2, ensure_ascii=False)
    print("  [✓] metrics.json")

    with open(os.path.join(output_dir, "feature_names.json"), 'w') as f:
        json.dump(feature_names, f)
    print("  [✓] feature_names.json")


def load_artifacts(models_dir: str = None) -> dict:
    """
    Charge tous les artefacts sauvegardés.
    Retourne un dictionnaire avec les modèles prêts à l'emploi.
    """
    if models_dir is None:
        models_dir = MODELS_DIR
    return {
        'rf': joblib.load(os.path.join(models_dir, "rf_model.joblib")),
        'knn': joblib.load(os.path.join(models_dir, "knn_model.joblib")),
        'scaler': joblib.load(os.path.join(models_dir, "scaler.joblib")),
        'encoders': joblib.load(os.path.join(models_dir, "encoders.joblib")),
        'metrics': json.load(open(os.path.join(models_dir, "metrics.json"))),
        'feature_names': json.load(open(os.path.join(models_dir, "feature_names.json"))),
    }
