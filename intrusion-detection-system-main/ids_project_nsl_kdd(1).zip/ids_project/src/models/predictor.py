"""
Module de prédiction (inférence en production)
Charge les modèles sauvegardés et classifie de nouvelles connexions.
"""
import numpy as np
import pandas as pd
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import COLUMNS, ATTACK_CATEGORIES, CATEGORY_COLORS
from src.models.trainer import load_artifacts
from src.preprocessing.data_loader import encode_single


class IDSPredictor:
    """
    Classe principale pour la prédiction en temps réel.
    Encapsule les modèles RF et KNN avec leur pipeline de prétraitement.
    """

    def __init__(self, models_dir: str = None):
        print("[IDS] Chargement des modèles...")
        arts = load_artifacts(models_dir)
        self.rf = arts['rf']
        self.knn = arts['knn']
        self.scaler = arts['scaler']
        self.encoders = arts['encoders']
        self.feature_names = arts['feature_names']
        self.metrics = arts['metrics']
        print("[IDS] Modèles chargés avec succès.")

    def _prepare_input(self, raw: dict) -> np.ndarray:
        """
        Transforme un dictionnaire de features brutes en vecteur normalisé.
        """
        # Valeurs par défaut (connexion HTTP normale type)
        defaults = {
            'duration': 0, 'protocol_type': 'tcp', 'service': 'http',
            'flag': 'SF', 'src_bytes': 0, 'dst_bytes': 0, 'land': '0',
            'wrong_fragment': 0, 'urgent': 0, 'hot': 0,
            'num_failed_logins': 0, 'logged_in': '0', 'num_compromised': 0,
            'root_shell': 0, 'su_attempted': 0, 'num_root': 0,
            'num_file_creations': 0, 'num_shells': 0, 'num_access_files': 0,
            'num_outbound_cmds': 0, 'is_host_login': '0', 'is_guest_login': '0',
            'count': 1, 'srv_count': 1, 'serror_rate': 0.0,
            'srv_serror_rate': 0.0, 'rerror_rate': 0.0, 'srv_rerror_rate': 0.0,
            'same_srv_rate': 1.0, 'diff_srv_rate': 0.0, 'srv_diff_host_rate': 0.0,
            'dst_host_count': 1, 'dst_host_srv_count': 1,
            'dst_host_same_srv_rate': 1.0, 'dst_host_diff_srv_rate': 0.0,
            'dst_host_same_src_port_rate': 0.0, 'dst_host_srv_diff_host_rate': 0.0,
            'dst_host_serror_rate': 0.0, 'dst_host_srv_serror_rate': 0.0,
            'dst_host_rerror_rate': 0.0, 'dst_host_srv_rerror_rate': 0.0,
        }
        defaults.update(raw)
        df = pd.DataFrame([defaults])
        df = encode_single(df, self.encoders)
        # Garder seulement les features nécessaires dans le bon ordre
        for col in self.feature_names:
            if col not in df.columns:
                df[col] = 0
        X = df[self.feature_names].values.astype(float)
        X_scaled = self.scaler.transform(X)
        return X_scaled

    def predict(self, raw_features: dict, model: str = 'rf') -> dict:
        """
        Prédit la classe d'une connexion réseau.

        Args:
            raw_features: dictionnaire des attributs de la connexion
            model: 'rf' ou 'knn'

        Returns:
            dict avec predicted_label, category, confidence, color
        """
        X = self._prepare_input(raw_features)
        clf = self.rf if model == 'rf' else self.knn
        label = clf.predict(X)[0]
        category = ATTACK_CATEGORIES.get(label, 'Unknown')
        color = CATEGORY_COLORS.get(category, '#888780')

        # Probabilités (RF supporte predict_proba, KNN aussi)
        if hasattr(clf, 'predict_proba'):
            proba = clf.predict_proba(X)[0]
            classes = clf.classes_
            conf_map = {str(c): float(round(p * 100, 2))
                        for c, p in zip(classes, proba)}
            confidence = float(round(max(proba) * 100, 2))
        else:
            conf_map = {label: 100.0}
            confidence = 100.0

        # Top 5 probabilités
        top5 = sorted(conf_map.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            'predicted_label': label,
            'category': category,
            'color': color,
            'confidence': confidence,
            'top5': top5,
            'model': model.upper(),
            'is_attack': category != 'Normal',
        }

    def predict_both(self, raw_features: dict) -> dict:
        """Lance la prédiction avec RF et KNN et compare les résultats."""
        rf_result = self.predict(raw_features, model='rf')
        knn_result = self.predict(raw_features, model='knn')
        agreement = rf_result['predicted_label'] == knn_result['predicted_label']
        return {
            'rf': rf_result,
            'knn': knn_result,
            'agreement': agreement,
            'consensus': rf_result['predicted_label'] if agreement else 'Divergence'
        }

    def get_metrics(self) -> dict:
        """Retourne les métriques de performance des deux modèles."""
        return self.metrics
