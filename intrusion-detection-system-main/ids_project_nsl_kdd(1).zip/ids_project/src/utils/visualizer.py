"""
Module de visualisation des résultats
Génère des graphiques matplotlib/seaborn pour le rapport
"""
import os, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import CATEGORY_COLORS, MODELS_DIR

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'static', 'img')
os.makedirs(OUTPUT_DIR, exist_ok=True)

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 11,
    'axes.spines.top': False, 'axes.spines.right': False,
    'figure.dpi': 100, 'savefig.dpi': 120,
    'savefig.bbox': 'tight', 'savefig.facecolor': 'white'
})


def plot_class_distribution(class_dist: dict, title='Distribution des classes (Train)'):
    """Barplot de la distribution des classes."""
    fig, ax = plt.subplots(figsize=(12, 5))
    items = sorted(class_dist.items(), key=lambda x: x[1], reverse=True)
    labels = [k for k, _ in items]
    vals = [v for _, v in items]
    colors = ['#1a73e8' if v == max(vals) else '#93c5fd' for v in vals]
    bars = ax.bar(labels, vals, color=colors, edgecolor='white', linewidth=0.8, zorder=2)
    ax.set_title(title, fontsize=14, fontweight='bold', pad=16)
    ax.set_ylabel("Nombre d'échantillons")
    ax.tick_params(axis='x', rotation=45)
    ax.yaxis.grid(True, alpha=0.3, zorder=0)
    ax.set_axisbelow(True)
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(vals)*0.01,
                f'{val:,}', ha='center', va='bottom', fontsize=9)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, 'class_distribution.png')
    fig.savefig(path); plt.close(fig)
    print(f"  [✓] {path}")
    return path


def plot_confusion_matrix(cm: list, labels: list, model_name: str):
    """Heatmap de la matrice de confusion."""
    fig, ax = plt.subplots(figsize=(7, 5.5))
    cm_arr = np.array(cm)
    sns.heatmap(cm_arr, annot=True, fmt=',d', cmap='Blues',
                xticklabels=labels, yticklabels=labels,
                linewidths=0.5, linecolor='white', ax=ax,
                annot_kws={'size': 10})
    ax.set_title(f'Matrice de confusion — {model_name}', fontsize=13, fontweight='bold', pad=14)
    ax.set_xlabel('Prédit', fontsize=11)
    ax.set_ylabel('Réel', fontsize=11)
    plt.tight_layout()
    fname = f'cm_{model_name.lower().replace(" ","_")}.png'
    path = os.path.join(OUTPUT_DIR, fname)
    fig.savefig(path); plt.close(fig)
    print(f"  [✓] {path}")
    return path


def plot_model_comparison(rf_metrics: dict, knn_metrics: dict):
    """Graphique comparatif RF vs KNN."""
    cats = ['Normal', 'DoS', 'Probe', 'R2L', 'U2R']
    metrics_names = ['Précision', 'Rappel', 'F1-Score']
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle('Comparaison Random Forest vs KNN par catégorie', fontsize=14, fontweight='bold', y=1.02)
    metric_keys = ['precision', 'recall', 'f1-score']
    for i, (mname, mkey) in enumerate(zip(metrics_names, metric_keys)):
        ax = axes[i]
        rf_vals = [rf_metrics.get('cat_report', {}).get(c, {}).get(mkey, 0) * 100 for c in cats]
        knn_vals = [knn_metrics.get('cat_report', {}).get(c, {}).get(mkey, 0) * 100 for c in cats]
        x = np.arange(len(cats)); w = 0.35
        b1 = ax.bar(x - w/2, rf_vals, w, label='RF', color='#1a73e8', alpha=0.85, zorder=2)
        b2 = ax.bar(x + w/2, knn_vals, w, label='KNN', color='#7c3aed', alpha=0.85, zorder=2)
        ax.set_title(mname, fontweight='bold', fontsize=12)
        ax.set_xticks(x); ax.set_xticklabels(cats, fontsize=10)
        ax.set_ylim(0, 110); ax.yaxis.grid(True, alpha=0.3)
        ax.set_axisbelow(True); ax.set_ylabel('%')
        ax.legend(fontsize=9)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, 'model_comparison.png')
    fig.savefig(path); plt.close(fig)
    print(f"  [✓] {path}")
    return path


def plot_feature_importance(top_features: list):
    """Barplot horizontal des importances de features."""
    names = [f[0] for f in top_features[:15]]
    values = [f[1] * 100 for f in top_features[:15]]
    fig, ax = plt.subplots(figsize=(9, 6))
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(names)))[::-1]
    bars = ax.barh(names[::-1], values[::-1], color=colors[::-1], edgecolor='white', zorder=2)
    ax.set_title('Top 15 features les plus importantes (RF)', fontsize=13, fontweight='bold', pad=14)
    ax.set_xlabel('Importance (%)')
    ax.xaxis.grid(True, alpha=0.3, zorder=0); ax.set_axisbelow(True)
    for bar, val in zip(bars, values[::-1]):
        ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2,
                f'{val:.2f}%', va='center', fontsize=9)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, 'feature_importance.png')
    fig.savefig(path); plt.close(fig)
    print(f"  [✓] {path}")
    return path


def generate_all_plots(metrics_path: str = None):
    """Génère tous les graphiques à partir du fichier metrics.json."""
    if metrics_path is None:
        metrics_path = os.path.join(MODELS_DIR, 'metrics.json')
    with open(metrics_path) as f:
        m = json.load(f)
    print("\n[Visualisation] Génération des graphiques...")
    plot_class_distribution(m.get('class_distribution', {}))
    plot_confusion_matrix(m['rf']['confusion_matrix'], m['rf']['cm_labels'], 'Random Forest')
    plot_confusion_matrix(m['knn']['confusion_matrix'], m['knn']['cm_labels'], 'KNN')
    plot_model_comparison(m['rf'], m['knn'])
    plot_feature_importance(m.get('top_features', []))
    print("[✓] Tous les graphiques générés dans static/img/")


if __name__ == '__main__':
    generate_all_plots()
