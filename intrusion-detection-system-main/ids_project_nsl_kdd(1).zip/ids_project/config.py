"""
Configuration globale du projet IDS NSL-KDD
"""
import os

# Chemins
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODELS_DIR = os.path.join(BASE_DIR, "models")
STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

# Fichiers de données
TRAIN_FILE = os.path.join(DATA_DIR, "KDDTrain_.txt")
TEST_FILE = os.path.join(DATA_DIR, "KDDTest_.txt")
TEST21_FILE = os.path.join(DATA_DIR, "KDDTest-21.txt")
TRAIN_20PCT_FILE = os.path.join(DATA_DIR, "KDDTrain__20Percent.txt")

# Fichiers modèles sauvegardés
RF_MODEL_PATH = os.path.join(MODELS_DIR, "rf_model.joblib")
KNN_MODEL_PATH = os.path.join(MODELS_DIR, "knn_model.joblib")
SCALER_PATH = os.path.join(MODELS_DIR, "scaler.joblib")
ENCODERS_PATH = os.path.join(MODELS_DIR, "encoders.joblib")
METRICS_PATH = os.path.join(MODELS_DIR, "metrics.json")
FEATURES_PATH = os.path.join(MODELS_DIR, "feature_names.json")

# Colonnes NSL-KDD
COLUMNS = [
    'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
    'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
    'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
    'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
    'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
    'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate',
    'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'label', 'difficulty'
]

# Catégories d'attaques
ATTACK_CATEGORIES = {
    'normal': 'Normal',
    # DoS - Denial of Service
    'back': 'DoS', 'land': 'DoS', 'neptune': 'DoS', 'pod': 'DoS',
    'smurf': 'DoS', 'teardrop': 'DoS', 'apache2': 'DoS', 'udpstorm': 'DoS',
    'processtable': 'DoS', 'worm': 'DoS', 'mailbomb': 'DoS',
    # Probe - Surveillance & Scanning
    'satan': 'Probe', 'ipsweep': 'Probe', 'nmap': 'Probe', 'portsweep': 'Probe',
    'mscan': 'Probe', 'saint': 'Probe',
    # R2L - Remote to Local
    'guess_passwd': 'R2L', 'ftp_write': 'R2L', 'imap': 'R2L', 'phf': 'R2L',
    'multihop': 'R2L', 'warezmaster': 'R2L', 'warezclient': 'R2L', 'spy': 'R2L',
    'xlock': 'R2L', 'xsnoop': 'R2L', 'snmpguess': 'R2L', 'snmpgetattack': 'R2L',
    'httptunnel': 'R2L', 'sendmail': 'R2L', 'named': 'R2L',
    # U2R - User to Root
    'buffer_overflow': 'U2R', 'loadmodule': 'U2R', 'rootkit': 'U2R',
    'perl': 'U2R', 'sqlattack': 'U2R', 'xterm': 'U2R', 'ps': 'U2R'
}

# Couleurs par catégorie
CATEGORY_COLORS = {
    'Normal': '#34a853',
    'DoS':    '#ea4335',
    'Probe':  '#fbbc04',
    'R2L':    '#9c27b0',
    'U2R':    '#ff5722',
    'Unknown':'#888780'
}

# Paramètres des modèles
RF_PARAMS = {
    'n_estimators': 100,
    'max_depth': 20,
    'random_state': 42,
    'n_jobs': -1,
    'class_weight': 'balanced'
}

KNN_PARAMS = {
    'n_neighbors': 5,
    'n_jobs': -1,
    'metric': 'euclidean'
}

KNN_TRAIN_SUBSET = 30000  # Sous-ensemble pour KNN (performance)

# API Flask
API_HOST = '0.0.0.0'
API_PORT = 5000
DEBUG = True
