"""
Point d'entrée principal — Lance l'interface web IDS
Usage : python run.py
        Puis ouvrir : http://localhost:5000
"""
import os, sys

# S'assurer que le répertoire racine est dans le path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT_DIR)

from config import API_HOST, API_PORT, DEBUG, MODELS_DIR
from src.models.predictor import IDSPredictor
from flask import Flask, request, jsonify, render_template, abort
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__,
            template_folder=os.path.join(ROOT_DIR, 'templates'),
            static_folder=os.path.join(ROOT_DIR, 'static'))
CORS(app)

predictor = None
prediction_history = []

def get_predictor():
    global predictor
    if predictor is None:
        predictor = IDSPredictor(MODELS_DIR)
    return predictor

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'timestamp': datetime.now().isoformat(),
                    'models_loaded': predictor is not None,
                    'predictions_made': len(prediction_history)})

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)
    if not data:
        abort(400, description="Corps JSON requis")
    model = data.pop('model', 'rf')
    if model not in ('rf', 'knn'):
        abort(400, description="model doit être 'rf' ou 'knn'")
    try:
        result = get_predictor().predict(data, model=model)
        result['timestamp'] = datetime.now().isoformat()
        result['input_features'] = data
        prediction_history.append({
            'id': len(prediction_history) + 1,
            'timestamp': result['timestamp'],
            'model': model.upper(),
            'label': result['predicted_label'],
            'category': result['category'],
            'confidence': result['confidence'],
            'is_attack': result['is_attack'],
            'protocol': data.get('protocol_type', '?'),
            'src_bytes': data.get('src_bytes', 0),
            'dst_bytes': data.get('dst_bytes', 0),
        })
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict_both', methods=['POST'])
def predict_both():
    data = request.get_json(force=True)
    if not data:
        abort(400)
    try:
        result = get_predictor().predict_both(data)
        result['timestamp'] = datetime.now().isoformat()
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/metrics', methods=['GET'])
def metrics():
    try:
        return jsonify(get_predictor().get_metrics())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/history', methods=['GET'])
def history():
    limit = int(request.args.get('limit', 50))
    category = request.args.get('category', None)
    items = prediction_history[::-1]
    if category:
        items = [i for i in items if i['category'] == category]
    return jsonify({'total': len(prediction_history), 'items': items[:limit]})

@app.route('/api/history', methods=['DELETE'])
def clear_history():
    global prediction_history
    prediction_history = []
    return jsonify({'message': 'Historique effacé'})

@app.route('/api/history/stats', methods=['GET'])
def history_stats():
    if not prediction_history:
        return jsonify({'total': 0, 'by_category': {}, 'attack_rate': 0})
    by_cat = {}
    attacks = 0
    for p in prediction_history:
        cat = p['category']
        by_cat[cat] = by_cat.get(cat, 0) + 1
        if p['is_attack']:
            attacks += 1
    return jsonify({'total': len(prediction_history), 'by_category': by_cat,
                    'attack_rate': round(attacks / len(prediction_history) * 100, 2),
                    'attacks': attacks, 'normal': len(prediction_history) - attacks})

@app.errorhandler(400)
def bad_request(e): return jsonify({'error': str(e)}), 400
@app.errorhandler(404)
def not_found(e): return jsonify({'error': 'Route non trouvée'}), 404
@app.errorhandler(500)
def server_error(e): return jsonify({'error': 'Erreur serveur'}), 500

if __name__ == '__main__':
    print("\n" + "="*52)
    print("  IDS — Système de Détection d'Intrusion")
    print("="*52)
    print(f"  Dossier projet : {ROOT_DIR}")
    print(f"  Modèles        : {MODELS_DIR}")
    print(f"  Interface      : http://localhost:{API_PORT}")
    print("="*52)
    print("\n  Chargement des modèles RF + KNN...")
    get_predictor()
    print("  Modèles chargés. Démarrage du serveur...\n")
    app.run(host=API_HOST, port=API_PORT, debug=DEBUG)
