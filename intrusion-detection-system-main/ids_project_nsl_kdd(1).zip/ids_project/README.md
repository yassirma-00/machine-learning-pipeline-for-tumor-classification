# 🛡️ IDS — Système de Détection d'Intrusion (NSL-KDD)

Système de détection d'intrusion réseau basé sur le machine learning,
utilisant le dataset **NSL-KDD** avec une classification multi-classes.

---

## 📁 Structure du projet

```
ids_project/
├── data/                         # Données NSL-KDD
│   ├── KDDTrain_.txt             # 125 973 échantillons
│   ├── KDDTest_.txt              # 22 544 échantillons
│   ├── KDDTest-21.txt            # Variante test
│   └── KDDTrain__20Percent.txt   # 20% du train
│
├── models/                       # Artefacts sauvegardés (après entraînement)
│   ├── rf_model.joblib
│   ├── knn_model.joblib
│   ├── scaler.joblib
│   ├── encoders.joblib
│   └── metrics.json
│
├── src/
│   ├── preprocessing/
│   │   └── data_loader.py        # Chargement, encodage, normalisation
│   ├── models/
│   │   ├── trainer.py            # Entraînement RF + KNN
│   │   └── predictor.py          # Inférence en production
│   ├── api/
│   │   └── app.py                # API Flask REST
│   └── utils/
│       └── visualizer.py         # Graphiques matplotlib/seaborn
│
├── static/
│   ├── css/style.css             # Interface graphique
│   └── js/app.js                 # JavaScript frontend
│
├── templates/
│   └── index.html                # Page HTML principale
│
├── tests/
│   └── test_pipeline.py          # Tests unitaires pytest
│
├── notebooks/                    # (optionnel) Jupyter notebooks
│
├── config.py                     # Configuration globale
├── train.py                      # Script principal d'entraînement
└── requirements.txt              # Dépendances Python
```

---

## 🚀 Installation et démarrage

### 1. Prérequis
```bash
Python 3.9+
pip install -r requirements.txt
```

### 2. Placer les données
Copier les fichiers NSL-KDD dans le dossier `data/` :
```
data/KDDTrain_.txt
data/KDDTest_.txt
data/KDDTest-21.txt
data/KDDTrain__20Percent.txt
```

### 3. Entraîner les modèles
```bash
python train.py
```
Ce script exécute le pipeline complet :
- Prétraitement des données
- Entraînement Random Forest + KNN
- Évaluation et métriques
- Sauvegarde dans `models/`

### 4. Lancer l'interface
```bash
python src/api/app.py
```
Ouvrir : **http://localhost:5000**

### 5. (Optionnel) Générer les graphiques
```bash
python src/utils/visualizer.py
```

### 6. Exécuter les tests
```bash
python -m pytest tests/ -v
```

---

## 🧠 Modèles et résultats

| Modèle | Accuracy | F1 Macro | Cat. Accuracy |
|--------|----------|----------|---------------|
| Random Forest | **72.2%** | 51% | 74.4% |
| KNN (k=5) | 70.5% | 48% | 75.1% |

### Catégories d'attaques

| Catégorie | Description | Exemples |
|-----------|-------------|---------|
| **Normal** | Trafic légitime | — |
| **DoS** | Déni de service | neptune, smurf, teardrop |
| **Probe** | Scan/reconnaissance | ipsweep, nmap, portsweep |
| **R2L** | Remote to Local | guess_passwd, warezclient |
| **U2R** | User to Root | buffer_overflow, rootkit |

---

## 🖥️ Interface graphique

L'interface comprend 5 onglets :

1. **Tableau de bord** — KPIs, distribution des classes, comparaison modèles
2. **Détection temps réel** — Formulaire de classification + flux d'alertes
3. **Performances** — Métriques détaillées, matrices de confusion, radar P/R
4. **Analyse Features** — Top 15 importances (Random Forest)
5. **Historique** — Journal de toutes les prédictions de la session

---

## 🔌 API REST

| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/health` | Santé du service |
| POST | `/api/predict` | Prédiction simple (RF ou KNN) |
| POST | `/api/predict_both` | Prédiction RF + KNN comparée |
| GET | `/api/metrics` | Métriques de performance |
| GET | `/api/history` | Historique des prédictions |
| DELETE | `/api/history` | Effacer l'historique |
| GET | `/api/history/stats` | Statistiques agrégées |

### Exemple de requête
```bash
curl -X POST http://localhost:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "model": "rf",
    "protocol_type": "tcp",
    "service": "private",
    "flag": "S0",
    "src_bytes": 0,
    "dst_bytes": 0,
    "count": 123,
    "serror_rate": 1.0,
    "same_srv_rate": 0.05
  }'
```

---

## 📊 Dataset NSL-KDD

- **Source** : Canadian Institute for Cybersecurity
- **Train** : 125 973 connexions réseau
- **Test** : 22 544 connexions
- **Features** : 41 attributs (réseau + statistiques)
- **Classes** : 23 types d'attaques + Normal

---

## 👨‍💻 Technologies utilisées

- **Python 3.9+**
- **scikit-learn** — Random Forest, KNN, métriques
- **pandas / numpy** — Manipulation des données
- **Flask** — API REST backend
- **Chart.js** — Visualisations interactives
- **matplotlib / seaborn** — Graphiques statiques
- **joblib** — Sérialisation des modèles
